package refugioAdopciones;

public enum tipoSocio{
    voluntario,
    donante,
    adoptante
}