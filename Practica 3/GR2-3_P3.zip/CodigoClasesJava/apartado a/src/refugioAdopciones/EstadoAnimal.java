package refugioAdopciones;

public enum EstadoAnimal{
    disponible,
    adoptado,
    enTratamiento
}