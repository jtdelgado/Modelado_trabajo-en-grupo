import java.util.*;

public interface PromotionStrategy {
    public int applyDiscount(int price);
}